//JSON
{
	artiklar:
	[
		{
			id: "aj1",
			sommarvara: true,
			vintervara: false,
			namn: "Fotboll",
			beskrivning: "En fotboll av läder",
			pris: 10,
			enhetspris: -1,
			kategorier: "Fotboll Redskap"
		},
		{
			id: "aj2",
			sommarvara: false, 
			vintervara: true,
			namn: "Skidor",
			beskrivning: "Träplankor för enklare förflyttning på snö",
			pris: 20,
			enhetspris: -1,
			kategorier: "Skidor Redskap"
			
		},
		{
			id: "aj3",
			sommarvara: false, 
			vintervara: true,
			namn: "Skidbyxa",
			beskrivning: "Klädesplagg för att bättre klara vinterkyla",
			pris: 30,
			enhetspris: -1,
			kategorier: "Skidor Klädesplagg"
		},
		{
			id: "aj4",
			sommarvara: true,
			vintervara: false,
			namn: "Fotboll",
			beskrivning: "En fotboll av läder",
			pris: 10,
			enhetspris: -1,
			kategorier: "Fotboll Redskap"
		}
	]
}